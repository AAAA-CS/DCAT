
%==============================================
clc;
clear all;
addpath(genpath(pwd));
% load the ground truth and the hyperspectral image

% path='E:\multi-domain learning\image\image4\';
path='F:\PaviaU\original\';

inputlabel = [path 'PaviaU_gt.mat'];
load(inputlabel);
Img_GT = paviaU_gt;
[m,n] = size(Img_GT);
imggt = reshape(Img_GT, [1, m*n]);
%======select training sample=============
% pathTrain = 'E:\multi-domain learning\sample\image4\TR_5\';
class = max(max(Img_GT));
TrainNO = 50;
TRLabel = zeros(size(Img_GT,1),size(Img_GT,2));
TSLabel = zeros(size(Img_GT,1),size(Img_GT,2));
for c = 1:class
    [Index,indey] = find(Img_GT == c);
    k1 = randperm(length(Index));
    PoX1 = Index(k1(1:TrainNO));
    PoY1 = indey(k1(1:TrainNO));

    for i = 1:length(PoX1)
        TRLabel(PoX1(i),PoY1(i)) = Img_GT(PoX1(i),PoY1(i));
    end
   
    PoX2 = Index(k1(TrainNO + 1:end));
    PoY2 = indey(k1(TrainNO + 1:end));
    %================================
    for i = 1:length(PoX2)
        TSLabel(PoX2(i),PoY2(i)) = Img_GT(PoX2(i),PoY2(i));
    end
    
    
%     k2 = randperm(length(Index));
%     PoX2 = Index(k2(1:TestNO));
%     PoY2 = indey(k2(1:TestNO));
%     %================================
%     for i = 1:length(PoX2)
%         TSLabel(PoX2(i),PoY2(i)) = Img_GT(PoX2(i),PoY2(i));
%     end

end
% TSLabel = Img_GT;
save 'TRLabel.mat' TRLabel
save 'TSLabel.mat' TSLabel


% Trainrate = 0.01;
% Testrate = 0.2;
% TRLabel = zeros(size(Img_GT,1),size(Img_GT,2));
% TSLabel = zeros(size(Img_GT,1),size(Img_GT,2));
% for c = 1:class
%     [Index,indey] = find(Img_GT == c);
%     TrainNO = uint16(Trainrate*length(Index));
%     k1 = randperm(length(Index));
%     PoX1 = Index(k1(1:TrainNO));
%     PoY1 = indey(k1(1:TrainNO));
% 
%     TestNO = uint16(Testrate*length(Index));
%     k2 = randperm(length(Index));
%     PoX2 = Index(k2(1:TestNO));
%     PoY2 = indey(k2(1:TestNO));
% 
%     for i = 1:length(PoX1)
%         TRLabel(PoX1(i),PoY1(i)) = Img_GT(PoX1(i),PoY1(i));
%     end
%     %================================
%     for i = 1:length(PoX2)
%         TSLabel(PoX2(i),PoY2(i)) = Img_GT(PoX2(i),PoY2(i));
%     end
% 
% end
% save 'TRLabel.mat' TRLabel
% save 'TSLabel.mat' TSLabel




